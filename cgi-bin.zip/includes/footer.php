<footer class="footer">
    <div class="container text-center">
        <span class="text-muted">
        <b style="font-family: 'poppins';">Copyright&copy;POKEBIO| All Rights Reserved | Contact:pokebio@gmail.com phone:+0753868021 Address:75 rue vincent Paris 6(75006)</b>
        </span>
        <div style="width:20px"></div>
        <a href=""><i class="fa fa-instagram fa-2x"  style="color:white;" ></i ></a>
         <a href=""><i class="fa fa-twitter fa-2x" style="color:white;" ></i ></a>
    </div>
</footer>
    