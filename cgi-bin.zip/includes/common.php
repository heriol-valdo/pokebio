<?php
$con=mysqli_connect("localhost","bhaf2949_zeufackvaldo","Demanou2@","bhaf2949_ecommerce");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}